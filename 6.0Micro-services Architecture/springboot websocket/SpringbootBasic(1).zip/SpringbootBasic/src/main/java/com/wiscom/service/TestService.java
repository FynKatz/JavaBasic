package com.wiscom.service;

import java.util.List;

import com.wiscom.bean.TestBean;

/**
* @author gavin
* @version 创建日期:2019年9月5日
*/

public interface TestService {
	public List<TestBean> httpTest();
}
