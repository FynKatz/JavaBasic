package com.wiscom.bean;
/**
* @author gavin
* @version 创建日期:2019年9月5日
*/

public class TestBean {
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}
